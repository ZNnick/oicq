package com.oicq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OicqApplicationTests {

    @Test
    void contextLoads() {
    }

}
